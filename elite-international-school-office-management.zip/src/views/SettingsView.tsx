import React, { useState, useEffect } from 'react';
import { useStaff } from '../context/StaffContext';
import { useNotification } from '../context/NotificationContext';
import { SchoolSettings, Staff } from '../types';
import {
  Settings,
  Building,
  Users,
  ShieldCheck,
  KeyRound,
  Plus,
  Save,
  CheckCircle,
  FileText,
  DollarSign,
  FileSpreadsheet,
  Lock,
  HardDrive,
  ShieldAlert,
  ArrowRight,
  Moon,
  Sun,
  Trash2,
  AlertTriangle,
  Sparkles,
  RefreshCw,
} from 'lucide-react';

interface SettingsViewProps {
  onOpenBulkImport?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onOpenBulkImport }) => {
  const { getHeaders, staffList, refreshStaff } = useStaff();
  const { showToast } = useNotification();

  const [settings, setSettings] = useState<Partial<SchoolSettings>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [showAddStaffModal, setShowAddStaffModal] = useState(false);
  const [pinModalStaff, setPinModalStaff] = useState<Staff | null>(null);
  const [newPin, setNewPin] = useState('');
  const [showClearDataModal, setShowClearDataModal] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);
  const [clearConfirmationText, setClearConfirmationText] = useState('');

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return document.documentElement.classList.contains('dark');
  });

  const handleToggleTheme = (dark: boolean) => {
    setIsDarkMode(dark);
    if (dark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('elite_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('elite_theme', 'light');
    }
  };

  // Add staff form
  const [newStaffForm, setNewStaffForm] = useState({
    name: '',
    role: 'Admissions Officer',
    email: '',
    phone: '',
    pin: '',
  });

  const fetchSettings = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        const data = await res.json();
        setSettings(data);
      }
    } catch (err) {
      console.error('Failed to load settings:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(settings),
      });
      if (res.ok) {
        showToast('School settings saved successfully', 'success');
        fetchSettings();
      }
    } catch (err) {
      showToast('Failed to save settings', 'error');
    }
  };

  const handleClearDemoData = async () => {
    if (clearConfirmationText !== 'CLEAR DEMO DATA') {
      showToast('Please type "CLEAR DEMO DATA" exactly to confirm', 'error');
      return;
    }

    setIsClearing(true);
    try {
      const res = await fetch('/api/settings/clear-demo-data', {
        method: 'POST',
        headers: getHeaders(),
      });
      if (res.ok) {
        showToast('All demo transactional and applicant data cleared', 'success');
        setShowClearDataModal(false);
        setClearConfirmationText('');
        fetchSettings();
        refreshStaff();
      } else {
        const errData = await res.json();
        showToast(errData.error || 'Failed to clear demo data', 'error');
      }
    } catch (err: any) {
      showToast('Error clearing data', 'error');
    } finally {
      setIsClearing(false);
    }
  };

  const handleSeedSampleData = async () => {
    setIsSeeding(true);
    try {
      const res = await fetch('/api/settings/seed-sample-data', {
        method: 'POST',
        headers: getHeaders(),
      });
      if (res.ok) {
        showToast('Full sample demo dataset restored successfully!', 'success');
        fetchSettings();
        refreshStaff();
      } else {
        const errData = await res.json();
        showToast(errData.error || 'Failed to restore sample data', 'error');
      }
    } catch (err: any) {
      showToast('Error restoring demo data', 'error');
    } finally {
      setIsSeeding(false);
    }
  };

  const handleAddStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStaffForm.name) {
      showToast('Staff name is required', 'error');
      return;
    }
    try {
      const res = await fetch('/api/staff', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify(newStaffForm),
      });
      if (res.ok) {
        showToast(`Staff profile '${newStaffForm.name}' created`, 'success');
        setShowAddStaffModal(false);
        setNewStaffForm({ name: '', role: 'Admissions Officer', email: '', phone: '', pin: '' });
        refreshStaff();
      }
    } catch (err) {
      showToast('Failed to create staff profile', 'error');
    }
  };

  const handleUpdatePin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pinModalStaff) return;
    try {
      const res = await fetch(`/api/staff/${pinModalStaff.id}/pin`, {
        method: 'PATCH',
        headers: getHeaders(),
        body: JSON.stringify({ pin: newPin }),
      });
      if (res.ok) {
        showToast(newPin ? 'Staff PIN code set' : 'Staff PIN code cleared', 'success');
        setPinModalStaff(null);
        setNewPin('');
        refreshStaff();
      }
    } catch (err) {
      showToast('Failed to update PIN', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-4 rounded-xl bg-card border border-border">
        <div className="eyebrow">Administration & Configuration</div>
        <h3 className="text-lg font-serif font-bold text-foreground">School Profile & Shared Terminal Staff</h3>
      </div>

      {/* Main Grid: School Settings Form on Left, Staff Management on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: School Settings */}
        <form onSubmit={handleSaveSettings} className="lg:col-span-2 space-y-6">
          <div className="panel p-6 space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-border">
              <Building className="w-4 h-4 text-primary" />
              <h4 className="font-serif font-bold text-sm text-foreground">Institutional Details & Academic Year</h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold mb-1">School Name</label>
                <input
                  type="text"
                  required
                  className="input"
                  value={settings.school_name || ''}
                  onChange={e => setSettings({ ...settings, school_name: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Latin Tagline</label>
                <input
                  type="text"
                  placeholder="e.g. Scientia est Infinita"
                  className="input"
                  value={settings.tagline || ''}
                  onChange={e => setSettings({ ...settings, tagline: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1">Institutional Motto</label>
              <input
                type="text"
                placeholder="e.g. To empower young minds with knowledge, skills, and values to create a future-ready generation."
                className="input text-xs"
                value={settings.motto || ''}
                onChange={e => setSettings({ ...settings, motto: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold mb-1">Official Telephone</label>
                <input
                  type="text"
                  placeholder="+94 70 699 9333"
                  className="input font-mono text-xs"
                  value={settings.phone || ''}
                  onChange={e => setSettings({ ...settings, phone: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Official Office Email</label>
                <input
                  type="email"
                  placeholder="office@eis.lk"
                  className="input font-mono text-xs"
                  value={settings.email || ''}
                  onChange={e => setSettings({ ...settings, email: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Official WhatsApp</label>
                <input
                  type="text"
                  placeholder="+94706999333"
                  className="input font-mono text-xs"
                  value={settings.whatsapp_number || ''}
                  onChange={e => setSettings({ ...settings, whatsapp_number: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1">Campus Physical Address</label>
              <input
                type="text"
                placeholder="1/143, Akuressa Road, Matara, Sri Lanka"
                className="input text-xs"
                value={settings.address || ''}
                onChange={e => setSettings({ ...settings, address: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold mb-1">Currency Symbol</label>
                <input
                  type="text"
                  className="input font-mono"
                  value={settings.currency_symbol || 'LKR'}
                  onChange={e => setSettings({ ...settings, currency_symbol: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Active Academic Term</label>
                <input
                  type="text"
                  className="input font-mono"
                  value={settings.academic_year || '2026-2027'}
                  onChange={e => setSettings({ ...settings, academic_year: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Total Student Capacity</label>
                <input
                  type="number"
                  className="input font-mono"
                  value={settings.total_student_capacity || '450'}
                  onChange={e => setSettings({ ...settings, total_student_capacity: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-border">
              <div>
                <label className="block text-xs font-semibold mb-1">Stalled Pipeline Alert Threshold (Days)</label>
                <input
                  type="number"
                  min="1"
                  max="90"
                  className="input font-mono text-xs"
                  placeholder="14"
                  value={settings.stalled_applicant_threshold_days || '14'}
                  onChange={e => setSettings({ ...settings, stalled_applicant_threshold_days: e.target.value })}
                />
                <p className="text-[10px] text-muted-foreground mt-0.5">Triggers reminder if applicant is inactive in a stage for this many days (Default: 14)</p>
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Desk Inactivity Auto-Lock (Minutes)</label>
                <input
                  type="number"
                  min="1"
                  max="120"
                  className="input font-mono text-xs"
                  placeholder="10"
                  value={settings.session_timeout_minutes || '10'}
                  onChange={e => setSettings({ ...settings, session_timeout_minutes: e.target.value })}
                />
                <p className="text-[10px] text-muted-foreground mt-0.5">Auto-locks terminal session after idle time</p>
              </div>
            </div>
          </div>

          {/* Sibling Discounts & Receipt Policy */}
          <div className="panel p-6 space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-border">
              <DollarSign className="w-4 h-4 text-accent" />
              <h4 className="font-serif font-bold text-sm text-foreground">Sibling Discount Rules & Receipt Notice</h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold mb-1">2nd Child Sibling Discount (%)</label>
                <input
                  type="number"
                  className="input font-mono"
                  value={settings.sibling_discount_2nd || '10'}
                  onChange={e => setSettings({ ...settings, sibling_discount_2nd: e.target.value })}
                />
                <p className="text-[10px] text-muted-foreground mt-0.5">Applied automatically to tuition billing</p>
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">3rd+ Child Sibling Discount (%)</label>
                <input
                  type="number"
                  className="input font-mono"
                  value={settings.sibling_discount_3rd || '15'}
                  onChange={e => setSettings({ ...settings, sibling_discount_3rd: e.target.value })}
                />
                <p className="text-[10px] text-muted-foreground mt-0.5">Applied for 3rd and subsequent siblings</p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1">Official Receipt Footer Legal Notice</label>
              <textarea
                className="textarea !h-20"
                value={settings.receipt_footer_notice || ''}
                onChange={e => setSettings({ ...settings, receipt_footer_notice: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1">Local PC Backup Folder Path</label>
              <input
                type="text"
                className="input font-mono text-xs"
                placeholder="e.g. C:\EliteSchoolOffice\Backups"
                value={settings.backup_folder_path || ''}
                onChange={e => setSettings({ ...settings, backup_folder_path: e.target.value })}
              />
            </div>

            <div className="flex justify-end pt-2">
              <button type="submit" className="btn btn-primary flex items-center gap-1.5">
                <Save className="w-3.5 h-3.5" />
                <span>Save System Settings</span>
              </button>
            </div>
          </div>
        </form>

        {/* Right 1 Col: Staff Profile & PIN Management & Theme */}
        <div className="space-y-6">
          <div className="panel p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-border">
              <div>
                <div className="eyebrow">Terminal Access</div>
                <h4 className="font-serif font-bold text-sm text-foreground">Staff Profiles ({staffList.length})</h4>
              </div>
              <button
                onClick={() => setShowAddStaffModal(true)}
                className="btn btn-primary text-xs flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>Add Staff</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {staffList.map(staff => (
                <div
                  key={staff.id}
                  className="p-3 rounded-xl bg-card border border-border flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-secondary text-primary font-bold text-xs flex items-center justify-center">
                      {staff.avatar_initials}
                    </div>
                    <div>
                      <div className="font-semibold text-xs text-foreground">{staff.name}</div>
                      <div className="text-[10px] text-muted-foreground">{staff.role}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        setPinModalStaff(staff);
                        setNewPin('');
                      }}
                      className={`btn text-[10px] !py-1 !px-2 flex items-center gap-1 ${
                        staff.has_pin ? 'btn-soft' : 'btn-ghost text-muted-foreground'
                      }`}
                      title={staff.has_pin ? 'Modify 4-Digit PIN' : 'Set 4-Digit PIN'}
                    >
                      <KeyRound className="w-3 h-3 text-accent" />
                      <span>{staff.has_pin ? 'PIN' : 'Set PIN'}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Theme Preference Panel */}
          <div className="panel p-5 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-border">
              <div>
                <div className="eyebrow">Appearance & Display</div>
                <h4 className="font-serif font-bold text-sm text-foreground">Terminal Theme</h4>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleToggleTheme(false)}
                className={`p-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-semibold transition-all ${
                  !isDarkMode
                    ? 'border-primary bg-primary/10 text-primary shadow-sm'
                    : 'border-border bg-card text-muted-foreground hover:text-foreground'
                }`}
              >
                <Sun className="w-4 h-4 text-amber-500" />
                <span>Light Theme</span>
              </button>

              <button
                type="button"
                onClick={() => handleToggleTheme(true)}
                className={`p-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-semibold transition-all ${
                  isDarkMode
                    ? 'border-primary bg-primary/10 text-primary shadow-sm'
                    : 'border-border bg-card text-muted-foreground hover:text-foreground'
                }`}
              >
                <Moon className="w-4 h-4 text-primary" />
                <span>Dark Theme</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Migration, Security & Danger Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Data Migration Panel */}
        <div className="panel p-6 border border-border space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="eyebrow">Data Import & Migration</div>
              <h3 className="text-base font-serif font-bold text-foreground">
                Bulk Student Import (CSV / Excel)
              </h3>
            </div>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
          </div>

          <p className="text-xs text-muted-foreground leading-relaxed">
            Migrate your school's existing student body in seconds. Upload an Excel or CSV file with full names, DOB, grade, and guardian contact details. Includes full validation, duplicate checks, and pre-commit preview.
          </p>

          <div className="pt-2">
            <button
              type="button"
              onClick={onOpenBulkImport}
              className="btn btn-primary text-xs flex items-center gap-2"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Launch Student Migration Tool</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Security & Data Privacy Compliance Panel */}
        <div className="panel p-6 border border-border space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="eyebrow">Security & Data Privacy</div>
              <h3 className="text-base font-serif font-bold text-foreground">
                Sensitive Records & Backup Hardening
              </h3>
            </div>
            <div className="p-2 rounded-xl bg-primary/10 text-primary">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>

          <div className="space-y-2 text-xs text-muted-foreground leading-relaxed">
            <div className="flex items-start gap-2">
              <Lock className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
              <span>
                <strong>Bcrypt Hashed PINs:</strong> Staff security PIN codes are never stored in plaintext and are hashed using bcrypt with salt rounds.
              </span>
            </div>
            <div className="flex items-start gap-2">
              <HardDrive className="w-3.5 h-3.5 text-accent shrink-0 mt-0.5" />
              <span>
                <strong>Encrypted Drive Backups:</strong> Database files contain student PII and financial records. Ensure downloaded <code className="text-primary font-mono text-[11px]">.db</code> files are stored exclusively on BitLocker / FileVault encrypted external drives.
              </span>
            </div>
            <div className="flex items-start gap-2">
              <ShieldAlert className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
              <span>
                <strong>Terminal Auto-Lock:</strong> Shared desk sessions automatically suspend on inactivity to prevent unauthorized access.
              </span>
            </div>
          </div>
        </div>

        {/* Danger Zone: Clear Demo Data */}
        <div className="panel p-6 border border-destructive/30 space-y-4 bg-destructive/5">
          <div className="flex items-center justify-between">
            <div>
              <div className="eyebrow text-destructive">Danger Zone</div>
              <h3 className="text-base font-serif font-bold text-foreground">
                Reset Demo Database
              </h3>
            </div>
            <div className="p-2 rounded-xl bg-destructive/10 text-destructive">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>

          <p className="text-xs text-muted-foreground leading-relaxed">
            Manage your school environment demo records. You can repopulate the complete institutional sample dataset (applicants, family records, fee structures, ledgers, assets) or clear demo records for production.
          </p>

          <div className="pt-2 flex flex-wrap gap-2">
            <button
              type="button"
              disabled={isSeeding || isClearing}
              onClick={handleSeedSampleData}
              className="btn btn-primary text-xs flex items-center gap-2 shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isSeeding ? 'Restoring Demo Records...' : 'Restore Sample Demo Dataset'}</span>
            </button>

            <button
              type="button"
              disabled={isSeeding || isClearing}
              onClick={() => {
                setClearConfirmationText('');
                setShowClearDataModal(true);
              }}
              className="btn btn-outline border-destructive/50 text-destructive hover:bg-destructive hover:text-destructive-foreground text-xs flex items-center gap-2"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All Demo Data</span>
            </button>
          </div>
        </div>
      </div>

      {/* Add Staff Modal */}
      {showAddStaffModal && (
        <div className="modal-backdrop" onClick={() => setShowAddStaffModal(false)}>
          <div className="modal !max-w-md" onClick={e => e.stopPropagation()}>
            <div className="eyebrow">Staff Management</div>
            <h3 className="text-lg font-serif font-bold text-foreground mb-4">Register New Staff Profile</h3>

            <form onSubmit={handleAddStaff} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Clara Montgomery"
                  className="input"
                  value={newStaffForm.name}
                  onChange={e => setNewStaffForm({ ...newStaffForm, name: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Office Role *</label>
                <select
                  className="select"
                  value={newStaffForm.role}
                  onChange={e => setNewStaffForm({ ...newStaffForm, role: e.target.value })}
                >
                  <option value="Head of School">Head of School</option>
                  <option value="Bursar & Accounts Head">Bursar & Accounts Head</option>
                  <option value="Admissions Officer">Admissions Officer</option>
                  <option value="Registrar">Registrar</option>
                  <option value="Front Desk Officer">Front Desk Officer</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Email</label>
                <input
                  type="email"
                  placeholder="staff@eliteschool.edu"
                  className="input"
                  value={newStaffForm.email}
                  onChange={e => setNewStaffForm({ ...newStaffForm, email: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Phone</label>
                <input
                  type="tel"
                  placeholder="+1 (555) 019-2811"
                  className="input"
                  value={newStaffForm.phone}
                  onChange={e => setNewStaffForm({ ...newStaffForm, phone: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">4-Digit Access PIN (Optional)</label>
                <input
                  type="password"
                  maxLength={6}
                  placeholder="1234"
                  className="input font-mono"
                  value={newStaffForm.pin}
                  onChange={e => setNewStaffForm({ ...newStaffForm, pin: e.target.value })}
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowAddStaffModal(false)} className="btn btn-ghost text-xs">Cancel</button>
                <button type="submit" className="btn btn-primary text-xs">Register Staff</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Set PIN Modal */}
      {pinModalStaff && (
        <div className="modal-backdrop" onClick={() => setPinModalStaff(null)}>
          <div className="modal !max-w-sm" onClick={e => e.stopPropagation()}>
            <div className="eyebrow">Security PIN</div>
            <h3 className="text-base font-serif font-bold text-foreground mb-1">
              Set PIN for {pinModalStaff.name}
            </h3>
            <p className="text-xs text-muted-foreground mb-4">
              Enter a 4-digit numeric code required when switching to this staff profile. Leave empty to remove PIN requirement.
            </p>

            <form onSubmit={handleUpdatePin} className="space-y-3">
              <div>
                <input
                  type="password"
                  maxLength={6}
                  autoFocus
                  placeholder="••••"
                  className="input text-center text-xl tracking-widest font-mono"
                  value={newPin}
                  onChange={e => setNewPin(e.target.value)}
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setPinModalStaff(null)} className="btn btn-ghost text-xs">Cancel</button>
                <button type="submit" className="btn btn-primary text-xs">Save PIN Code</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Clear Demo Data Confirmation Modal */}
      {showClearDataModal && (
        <div className="modal-backdrop" onClick={() => setShowClearDataModal(false)}>
          <div className="modal !max-w-md border border-destructive/40" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-2 text-destructive font-serif font-bold text-base mb-1">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              <span>Confirm Demo Data Reset</span>
            </div>
            <p className="text-xs text-muted-foreground mb-4">
              This action will permanently delete all demo students, applicants, payment receipts, family records, ledger entries, and audit trail logs. <strong>This action cannot be undone.</strong>
            </p>

            <div className="p-3 bg-card rounded-lg border border-border text-xs mb-4 space-y-1.5">
              <div className="font-semibold text-foreground">What will be cleared:</div>
              <ul className="list-disc list-inside text-muted-foreground text-[11px] space-y-0.5">
                <li>All applicants, active student dossiers, and enrollment records</li>
                <li>All fee payments, income ledger entries, and cash drawer reconciliations</li>
                <li>All operational expenses and payment audit logs</li>
              </ul>
              <div className="font-semibold text-foreground pt-1">What is preserved:</div>
              <ul className="list-disc list-inside text-muted-foreground text-[11px] space-y-0.5">
                <li>School settings & tuition fee scale definitions</li>
                <li>Staff login profiles and access credentials</li>
              </ul>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold mb-1">
                  Type <span className="font-mono text-destructive select-all">CLEAR DEMO DATA</span> to confirm:
                </label>
                <input
                  type="text"
                  placeholder="CLEAR DEMO DATA"
                  className="input font-mono text-xs border-destructive/40 focus:border-destructive"
                  value={clearConfirmationText}
                  onChange={e => setClearConfirmationText(e.target.value)}
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-border">
                <button
                  type="button"
                  disabled={isClearing}
                  onClick={() => {
                    setShowClearDataModal(false);
                    setClearConfirmationText('');
                  }}
                  className="btn btn-ghost text-xs"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={clearConfirmationText !== 'CLEAR DEMO DATA' || isClearing}
                  onClick={handleClearDemoData}
                  className="btn bg-destructive hover:bg-destructive/90 text-destructive-foreground text-xs flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>{isClearing ? 'Clearing Database...' : 'Permanently Clear Demo Data'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

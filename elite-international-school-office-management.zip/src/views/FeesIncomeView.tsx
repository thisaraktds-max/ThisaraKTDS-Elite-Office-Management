import React, { useState, useEffect, useMemo } from 'react';
import { useStaff } from '../context/StaffContext';
import { useNotification } from '../context/NotificationContext';
import { FeeStructure, Income } from '../types';
import {
  Receipt,
  Plus,
  Printer,
  Search,
  Layers,
  ChevronDown,
  ChevronRight,
  GraduationCap,
  ListFilter,
  CreditCard,
} from 'lucide-react';

interface FeesIncomeViewProps {
  onOpenNewIncome: () => void;
  onOpenReceiptModal: (receiptId: string) => void;
  onOpenDossier: (applicantId: string) => void;
}

export const FeesIncomeView: React.FC<FeesIncomeViewProps> = ({
  onOpenNewIncome,
  onOpenReceiptModal,
  onOpenDossier,
}) => {
  const { getHeaders } = useStaff();
  const { showToast } = useNotification();

  const [activeTab, setActiveTab] = useState<'income' | 'structure'>('income');
  const [viewStyle, setViewStyle] = useState<'grouped' | 'flat'>('grouped');
  const [incomes, setIncomes] = useState<Income[]>([]);
  const [feeStructures, setFeeStructures] = useState<FeeStructure[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [collapsedGrades, setCollapsedGrades] = useState<Record<string, boolean>>({});

  // Filters
  const [sourceFilter, setSourceFilter] = useState('all');
  const [methodFilter, setMethodFilter] = useState('all');
  const [gradeFilter, setGradeFilter] = useState('all');
  const [search, setSearch] = useState('');

  // New Fee Structure Modal
  const [showAddFeeModal, setShowAddFeeModal] = useState(false);
  const [newFee, setNewFee] = useState({
    academic_year: '2026-2027',
    grade: 'Grade 1',
    fee_type: 'Tuition',
    amount: '145000',
    is_compulsory: 1,
    description: 'Standard Annual Academic Tuition',
  });

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [incRes, feeRes] = await Promise.all([
        fetch('/api/income'),
        fetch('/api/fees'),
      ]);
      if (incRes.ok) setIncomes(await incRes.json());
      if (feeRes.ok) setFeeStructures(await feeRes.json());
    } catch (err) {
      console.error('Failed to load fees/income:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddFeeStructure = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/fees', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({
          ...newFee,
          amount: Number(newFee.amount),
        }),
      });
      if (res.ok) {
        showToast('Fee structure item registered successfully', 'success');
        setShowAddFeeModal(false);
        fetchData();
      }
    } catch (err) {
      showToast('Failed to add fee structure', 'error');
    }
  };

  const toggleGradeCollapse = (grade: string) => {
    setCollapsedGrades(prev => ({
      ...prev,
      [grade]: !prev[grade],
    }));
  };

  const filteredIncome = useMemo(() => {
    return incomes.filter(inc => {
      if (sourceFilter !== 'all' && inc.source !== sourceFilter) return false;
      if (methodFilter !== 'all' && inc.payment_method !== methodFilter) return false;
      const studentGrade = inc.student_grade || (inc.applicant_id ? 'Unspecified Grade' : 'Institutional');
      if (gradeFilter !== 'all' && studentGrade !== gradeFilter) return false;
      if (search) {
        const q = search.toLowerCase();
        return (
          inc.receipt_no.toLowerCase().includes(q) ||
          inc.payer_name.toLowerCase().includes(q) ||
          (inc.reference_no && inc.reference_no.toLowerCase().includes(q)) ||
          (inc.student_first_name && inc.student_first_name.toLowerCase().includes(q)) ||
          (inc.student_last_name && inc.student_last_name.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [incomes, sourceFilter, methodFilter, gradeFilter, search]);

  const totalIncomeSum = useMemo(() => {
    return filteredIncome.reduce((acc, i) => acc + Number(i.amount), 0);
  }, [filteredIncome]);

  // Group filtered incomes by Grade
  const groupedByGrade = useMemo(() => {
    const groups: Record<string, { total: number; count: number; items: Income[] }> = {};

    filteredIncome.forEach(inc => {
      const gradeKey = inc.student_grade || (inc.applicant_id ? 'Unspecified Grade' : 'Institutional / General');
      if (!groups[gradeKey]) {
        groups[gradeKey] = { total: 0, count: 0, items: [] };
      }
      groups[gradeKey].items.push(inc);
      groups[gradeKey].total += Number(inc.amount);
      groups[gradeKey].count += 1;
    });

    // Sort grades naturally
    const sortedKeys = Object.keys(groups).sort((a, b) => {
      if (a.includes('Kindergarten')) return -1;
      if (b.includes('Kindergarten')) return 1;
      if (a.includes('Institutional')) return 1;
      if (b.includes('Institutional')) return -1;
      const numA = parseInt(a.replace(/\D/g, ''), 10) || 0;
      const numB = parseInt(b.replace(/\D/g, ''), 10) || 0;
      return numA - numB;
    });

    return sortedKeys.map(key => ({
      grade: key,
      ...groups[key],
    }));
  }, [filteredIncome]);

  return (
    <div className="space-y-6">
      {/* Top Banner & Tab Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-card border border-border">
        <div className="flex items-center gap-3">
          <div className="flex rounded-lg border border-input p-0.5 bg-muted/40 text-xs">
            <button
              onClick={() => setActiveTab('income')}
              className={`px-3.5 py-1.5 rounded-md font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'income' ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground'
              }`}
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>Income & Receipts ({incomes.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('structure')}
              className={`px-3.5 py-1.5 rounded-md font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'structure' ? 'bg-primary text-primary-foreground shadow-sm' : 'text-muted-foreground'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Fee Structure Matrix ({feeStructures.length})</span>
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'income' ? (
            <button
              onClick={onOpenNewIncome}
              className="btn btn-primary text-xs flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Record Income / Payment</span>
            </button>
          ) : (
            <button
              onClick={() => setShowAddFeeModal(true)}
              className="btn btn-primary text-xs flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Fee Schedule Rule</span>
            </button>
          )}
        </div>
      </div>

      {activeTab === 'income' ? (
        /* INCOME LEDGER VIEW */
        <div className="space-y-4">
          {/* Filter Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              {/* Grouped vs Flat Toggle */}
              <div className="flex rounded-lg border border-border p-0.5 bg-muted/40 text-xs">
                <button
                  onClick={() => setViewStyle('grouped')}
                  className={`px-2.5 py-1 rounded-md font-medium flex items-center gap-1.5 transition-all ${
                    viewStyle === 'grouped'
                      ? 'bg-primary text-primary-foreground shadow-xs'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                  title="Group Payments by Grade"
                >
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span>Grouped by Grade</span>
                </button>
                <button
                  onClick={() => setViewStyle('flat')}
                  className={`px-2.5 py-1 rounded-md font-medium flex items-center gap-1.5 transition-all ${
                    viewStyle === 'flat'
                      ? 'bg-primary text-primary-foreground shadow-xs'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                  title="Flat Ledger View"
                >
                  <ListFilter className="w-3.5 h-3.5" />
                  <span>Flat Ledger</span>
                </button>
              </div>

              <select
                className="select !h-8 !py-0 !text-xs !w-36"
                value={sourceFilter}
                onChange={e => setSourceFilter(e.target.value)}
              >
                <option value="all">All Sources</option>
                <option value="Tuition">Tuition</option>
                <option value="Registration">Registration</option>
                <option value="Exam Fee">Exam Fee</option>
                <option value="Uniform">Uniform</option>
                <option value="Donation">Donation</option>
                <option value="Grant">Grant</option>
              </select>

              <select
                className="select !h-8 !py-0 !text-xs !w-36"
                value={methodFilter}
                onChange={e => setMethodFilter(e.target.value)}
              >
                <option value="all">All Methods</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Cash">Cash</option>
                <option value="Card">Card</option>
                <option value="Cheque">Cheque</option>
              </select>

              <div className="relative w-60">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                <input
                  type="text"
                  placeholder="Search receipt, payer..."
                  className="input !h-8 !pl-10 !text-xs w-full"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                />
              </div>
            </div>

            <div className="text-xs text-muted-foreground font-mono">
              Filtered Total: <strong className="text-emerald-600 dark:text-emerald-400 font-bold text-sm">LKR {totalIncomeSum.toLocaleString('en-US', { minimumFractionDigits: 2 })}</strong>
            </div>
          </div>

          {/* Grouped by Grade View */}
          {viewStyle === 'grouped' ? (
            <div className="space-y-4">
              {groupedByGrade.map(group => {
                const isCollapsed = collapsedGrades[group.grade];
                return (
                  <div key={group.grade} className="panel overflow-hidden border border-border shadow-2xs">
                    {/* Grade Header Summary Accordion */}
                    <div
                      onClick={() => toggleGradeCollapse(group.grade)}
                      className="p-4 bg-muted/40 hover:bg-muted/60 transition-colors flex items-center justify-between cursor-pointer border-b border-border select-none"
                    >
                      <div className="flex items-center gap-3">
                        <button className="p-1 rounded-md hover:bg-background/80 text-muted-foreground">
                          {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </button>
                        <div className="flex items-center gap-2">
                          <span className="font-serif font-bold text-sm text-foreground">{group.grade}</span>
                          <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-background border border-border text-muted-foreground">
                            {group.count} {group.count === 1 ? 'payment' : 'payments'}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className="text-[10px] text-muted-foreground uppercase tracking-wider block">Grade Total</span>
                          <span className="font-mono font-bold text-xs sm:text-sm text-emerald-600 dark:text-emerald-400">
                            LKR {group.total.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Grade Table Content */}
                    {!isCollapsed && (
                      <div className="overflow-x-auto">
                        <table className="table-clean w-full">
                          <thead>
                            <tr>
                              <th className="w-24">Receipt #</th>
                              <th className="w-24">Date</th>
                              <th>Payer / Remitter</th>
                              <th>Linked Student</th>
                              <th>Source</th>
                              <th>Payment Method</th>
                              <th>Received By</th>
                              <th className="text-right">Amount</th>
                              <th className="text-right w-20">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {group.items.map(inc => (
                              <tr key={inc.id} className="hover:bg-muted/20 transition-colors">
                                <td className="mono font-bold text-xs text-primary">{inc.receipt_no}</td>
                                <td className="text-xs text-muted-foreground mono">{inc.date}</td>
                                <td>
                                  <div className="font-semibold text-xs text-foreground">{inc.payer_name}</div>
                                </td>
                                <td>
                                  {inc.applicant_id ? (
                                    <div
                                      onClick={() => onOpenDossier(inc.applicant_id!)}
                                      className="text-xs font-medium text-primary hover:underline cursor-pointer"
                                    >
                                      {inc.student_first_name} {inc.student_last_name}
                                    </div>
                                  ) : (
                                    <span className="text-xs text-muted-foreground italic">Institutional</span>
                                  )}
                                </td>
                                <td>
                                  <span className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-muted text-foreground">
                                    {inc.source}
                                  </span>
                                </td>
                                <td className="text-xs text-muted-foreground">
                                  <div>{inc.payment_method}</div>
                                  {inc.reference_no && <div className="mono text-[10px] text-muted-foreground/70">{inc.reference_no}</div>}
                                </td>
                                <td className="text-xs text-muted-foreground">{inc.received_by_staff_name}</td>
                                <td className="text-right mono font-bold text-xs text-emerald-600 dark:text-emerald-400">
                                  +LKR {Number(inc.amount).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                                </td>
                                <td className="text-right">
                                  <button
                                    onClick={() => onOpenReceiptModal(inc.id)}
                                    className="btn btn-soft !py-1 !px-2 text-xs flex items-center gap-1 ml-auto"
                                    title="View / Print Receipt"
                                  >
                                    <Printer className="w-3 h-3" />
                                    <span>Receipt</span>
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                );
              })}

              {groupedByGrade.length === 0 && (
                <div className="panel p-12 text-center text-xs text-muted-foreground">
                  No income records match the selected filters.
                </div>
              )}
            </div>
          ) : (
            /* Flat Ledger Table View */
            <div className="panel overflow-hidden border border-border shadow-2xs">
              <div className="overflow-x-auto">
                <table className="table-clean w-full">
                  <thead>
                    <tr>
                      <th>Receipt #</th>
                      <th>Date</th>
                      <th>Payer / Remitter</th>
                      <th>Linked Student & Grade</th>
                      <th>Source</th>
                      <th>Payment Mode & Ref</th>
                      <th>Received By</th>
                      <th className="text-right">Amount</th>
                      <th className="text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredIncome.map(inc => (
                      <tr key={inc.id} className="hover:bg-muted/20 transition-colors">
                        <td className="mono font-bold text-xs text-primary">{inc.receipt_no}</td>
                        <td className="text-xs text-muted-foreground mono">{inc.date}</td>
                        <td>
                          <div className="font-semibold text-xs text-foreground">{inc.payer_name}</div>
                        </td>
                        <td>
                          {inc.applicant_id ? (
                            <div>
                              <div
                                onClick={() => onOpenDossier(inc.applicant_id!)}
                                className="text-xs font-medium text-primary hover:underline cursor-pointer"
                              >
                                {inc.student_first_name} {inc.student_last_name}
                              </div>
                              {inc.student_grade && (
                                <div className="text-[10px] text-muted-foreground">{inc.student_grade}</div>
                              )}
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground italic">General / Institutional</span>
                          )}
                        </td>
                        <td>
                          <span className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-muted text-foreground">
                            {inc.source}
                          </span>
                        </td>
                        <td className="text-xs text-muted-foreground">
                          <div>{inc.payment_method}</div>
                          {inc.reference_no && <div className="mono text-[10px]">{inc.reference_no}</div>}
                        </td>
                        <td className="text-xs text-muted-foreground">{inc.received_by_staff_name}</td>
                        <td className="text-right mono font-bold text-xs text-emerald-600 dark:text-emerald-400">
                          +LKR {Number(inc.amount).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="text-right">
                          <button
                            onClick={() => onOpenReceiptModal(inc.id)}
                            className="btn btn-soft !py-1 !px-2.5 text-xs flex items-center gap-1.5 ml-auto"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Receipt</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                    {filteredIncome.length === 0 && (
                      <tr>
                        <td colSpan={9} className="py-10 text-center text-xs text-muted-foreground">
                          No income entries match current filter criteria.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* FEE STRUCTURE MATRIX */
        <div className="panel p-6 space-y-4 border border-border shadow-2xs">
          <div className="flex items-center justify-between pb-3 border-b border-border">
            <div>
              <div className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Academic Pricing</div>
              <h3 className="text-base font-serif font-bold text-foreground">Standard Fee Schedules & Prescriptions</h3>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="table-clean w-full">
              <thead>
                <tr>
                  <th>Academic Year</th>
                  <th>Grade Level</th>
                  <th>Fee Classification</th>
                  <th>Description</th>
                  <th>Requirement</th>
                  <th className="text-right">Standard Amount</th>
                </tr>
              </thead>
              <tbody>
                {feeStructures.map(fee => (
                  <tr key={fee.id} className="hover:bg-muted/20 transition-colors">
                    <td className="mono text-xs text-muted-foreground">{fee.academic_year}</td>
                    <td className="font-semibold text-xs text-foreground">{fee.grade}</td>
                    <td className="font-medium text-xs text-primary">{fee.fee_type}</td>
                    <td className="text-xs text-muted-foreground">{fee.description || 'Standard rate'}</td>
                    <td>
                      {fee.is_compulsory === 1 ? (
                        <span className="badge badge-accepted !text-[10px]">Compulsory</span>
                      ) : (
                        <span className="badge badge-applied !text-[10px]">Optional</span>
                      )}
                    </td>
                    <td className="text-right mono font-bold text-xs text-foreground">
                      LKR {Number(fee.amount).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Fee Schedule Modal */}
      {showAddFeeModal && (
        <div className="modal-backdrop" onClick={() => setShowAddFeeModal(false)}>
          <div className="modal !max-w-md" onClick={e => e.stopPropagation()}>
            <div className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider">Fee Management</div>
            <h3 className="text-lg font-serif font-bold text-foreground mb-4">Register New Fee Schedule Item</h3>

            <form onSubmit={handleAddFeeStructure} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold mb-1">Academic Year</label>
                  <input
                    type="text"
                    required
                    className="input"
                    value={newFee.academic_year}
                    onChange={e => setNewFee({ ...newFee, academic_year: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold mb-1">Grade Level</label>
                  <select
                    className="select"
                    value={newFee.grade}
                    onChange={e => setNewFee({ ...newFee, grade: e.target.value })}
                  >
                    <option value="Kindergarten">Kindergarten</option>
                    <option value="Grade 1">Grade 1</option>
                    <option value="Grade 2">Grade 2</option>
                    <option value="Grade 3">Grade 3</option>
                    <option value="Grade 4">Grade 4</option>
                    <option value="Grade 5">Grade 5</option>
                    <option value="Grade 6">Grade 6</option>
                    <option value="Grade 7">Grade 7</option>
                    <option value="Grade 8">Grade 8</option>
                    <option value="Grade 9">Grade 9</option>
                    <option value="Grade 10">Grade 10</option>
                    <option value="Grade 11">Grade 11</option>
                    <option value="Grade 12">Grade 12</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold mb-1">Fee Type</label>
                  <select
                    className="select"
                    value={newFee.fee_type}
                    onChange={e => setNewFee({ ...newFee, fee_type: e.target.value })}
                  >
                    <option value="Tuition">Tuition Fee</option>
                    <option value="Registration">Registration / Matriculation</option>
                    <option value="Laboratory">Science / Tech Lab Fee</option>
                    <option value="Activity">Student Activities & Sports</option>
                    <option value="Technology">Technology Infrastructure</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold mb-1">Amount (LKR)</label>
                  <input
                    type="number"
                    step="1"
                    min="0"
                    required
                    className="input font-mono font-bold"
                    value={newFee.amount}
                    onChange={e => setNewFee({ ...newFee, amount: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Description</label>
                <input
                  type="text"
                  className="input"
                  value={newFee.description}
                  onChange={e => setNewFee({ ...newFee, description: e.target.value })}
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowAddFeeModal(false)} className="btn btn-ghost text-xs">Cancel</button>
                <button type="submit" className="btn btn-primary text-xs">Save Schedule Item</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

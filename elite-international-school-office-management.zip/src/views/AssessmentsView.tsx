import React, { useState, useEffect } from 'react';
import { useStaff } from '../context/StaffContext';
import { useNotification } from '../context/NotificationContext';
import { Assessment, Applicant } from '../types';
import {
  ClipboardCheck,
  Calendar,
  CheckCircle,
  Plus,
  Search,
  Filter,
  User,
  Clock,
  Award,
} from 'lucide-react';

export const AssessmentsView: React.FC<{ onOpenDossier: (id: string) => void }> = ({ onOpenDossier }) => {
  const { getHeaders } = useStaff();
  const { showToast } = useNotification();
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [applicants, setApplicants] = useState<Applicant[]>([]);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(true);

  // Modal / Form state
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [scheduleForm, setScheduleForm] = useState({
    applicant_id: '',
    assessment_type: 'Entrance Exam',
    interviewer_name: 'Dr. Vance / Admissions Panel',
    scheduled_at: new Date(Date.now() + 86400000 * 2).toISOString().substring(0, 10),
    max_score: '100',
    notes: '',
  });

  // Score modal state
  const [scoreModalAssessment, setScoreModalAssessment] = useState<Assessment | null>(null);
  const [scoreForm, setScoreForm] = useState({
    score: '',
    recommendation: 'Recommend Full Admission',
    notes: '',
  });

  const fetchAssessments = async () => {
    setIsLoading(true);
    try {
      const [assRes, appRes] = await Promise.all([
        fetch('/api/assessments'),
        fetch('/api/applicants'),
      ]);
      if (assRes.ok) {
        const data = await assRes.json();
        setAssessments(data);
      }
      if (appRes.ok) {
        const data = await appRes.json();
        setApplicants(data.applicants || []);
      }
    } catch (err) {
      console.error('Failed to load assessments:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAssessments();
  }, []);

  const handleScheduleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!scheduleForm.applicant_id) {
      showToast('Please select a student applicant', 'error');
      return;
    }
    try {
      const res = await fetch('/api/assessments', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({
          ...scheduleForm,
          max_score: Number(scheduleForm.max_score),
        }),
      });
      if (res.ok) {
        showToast('Assessment scheduled successfully', 'success');
        setShowScheduleModal(false);
        fetchAssessments();
      }
    } catch (err) {
      showToast('Failed to schedule assessment', 'error');
    }
  };

  const handleScoreSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!scoreModalAssessment) return;
    try {
      const res = await fetch(`/api/assessments/${scoreModalAssessment.id}/score`, {
        method: 'PATCH',
        headers: getHeaders(),
        body: JSON.stringify({
          score: Number(scoreForm.score),
          recommendation: scoreForm.recommendation,
          notes: scoreForm.notes,
        }),
      });
      if (res.ok) {
        showToast('Assessment evaluation recorded', 'success');
        setScoreModalAssessment(null);
        fetchAssessments();
      }
    } catch (err) {
      showToast('Failed to record score', 'error');
    }
  };

  const filtered = assessments.filter(a => {
    if (filterStatus === 'all') return true;
    return a.status.toLowerCase() === filterStatus.toLowerCase();
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-xl bg-card border border-border">
        <div>
          <div className="eyebrow">Academic Evaluation</div>
          <h3 className="text-lg font-serif font-bold text-foreground">Admissions Assessments & Interviews</h3>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex rounded-lg border border-input p-0.5 bg-muted/40 text-xs">
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${filterStatus === 'all' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}
            >
              All ({assessments.length})
            </button>
            <button
              onClick={() => setFilterStatus('scheduled')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${filterStatus === 'scheduled' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}
            >
              Upcoming ({assessments.filter(a => a.status === 'Scheduled').length})
            </button>
            <button
              onClick={() => setFilterStatus('completed')}
              className={`px-3 py-1 rounded-md font-medium transition-all ${filterStatus === 'completed' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}
            >
              Completed ({assessments.filter(a => a.status === 'Completed').length})
            </button>
          </div>

          <button
            onClick={() => setShowScheduleModal(true)}
            className="btn btn-primary text-xs flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Schedule Assessment</span>
          </button>
        </div>
      </div>

      {/* Assessments List Table */}
      <div className="panel overflow-hidden">
        <div className="w-full">
          <table className="table-clean w-full">
            <thead>
              <tr>
                <th className="w-1/4">Candidate & Grade</th>
                <th className="w-1/4">Assessment & Evaluator</th>
                <th className="w-1/6">Scheduled Date</th>
                <th className="w-1/5">Score & Recommendation</th>
                <th className="text-right">Status & Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(ass => (
                <tr key={ass.id} className="hover:bg-muted/30 transition-colors">
                  <td>
                    <div
                      onClick={() => onOpenDossier(ass.applicant_id)}
                      className="font-bold text-xs text-primary hover:underline cursor-pointer"
                    >
                      {ass.applicant_name}
                    </div>
                    <div className="inline-block text-[10px] font-medium text-muted-foreground mt-0.5 px-1.5 py-0.2 rounded bg-muted">
                      {ass.grade}
                    </div>
                  </td>
                  <td>
                    <div className="text-xs font-semibold text-foreground">
                      {ass.assessment_type}
                    </div>
                    <div className="text-[11px] text-muted-foreground mt-0.5">
                      {ass.interviewer_name}
                    </div>
                  </td>
                  <td>
                    <div className="mono text-xs text-foreground font-medium">{ass.scheduled_at}</div>
                  </td>
                  <td>
                    {ass.score !== null ? (
                      <div className="space-y-1">
                        <div className="mono font-bold text-xs text-foreground">
                          {ass.score} / {ass.max_score} <span className="text-muted-foreground font-normal">({Math.round((ass.score / ass.max_score) * 100)}%)</span>
                        </div>
                        {ass.recommendation && (
                          <div className="badge badge-accepted !text-[10px] truncate max-w-[220px]">
                            {ass.recommendation}
                          </div>
                        )}
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground italic">Pending evaluation</span>
                    )}
                  </td>
                  <td className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <span className={`badge ${ass.status === 'Completed' ? 'badge-accepted' : 'badge-applied'}`}>
                        {ass.status}
                      </span>
                      {ass.status !== 'Completed' ? (
                        <button
                          onClick={() => {
                            setScoreModalAssessment(ass);
                            setScoreForm({ score: '', recommendation: 'Recommend Full Admission', notes: ass.notes || '' });
                          }}
                          className="btn btn-primary !py-1 !px-2.5 text-xs"
                        >
                          Score
                        </button>
                      ) : (
                        <button
                          onClick={() => onOpenDossier(ass.applicant_id)}
                          className="btn btn-soft !py-1 !px-2.5 text-xs"
                        >
                          Dossier
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-xs text-muted-foreground">
                    No assessments match current filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Schedule Assessment Modal */}
      {showScheduleModal && (
        <div className="modal-backdrop" onClick={() => setShowScheduleModal(false)}>
          <div className="modal !max-w-md" onClick={e => e.stopPropagation()}>
            <div className="eyebrow">Academic Placement</div>
            <h3 className="text-lg font-serif font-bold text-foreground mb-4">Schedule Candidate Assessment</h3>

            <form onSubmit={handleScheduleSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold mb-1">Select Candidate *</label>
                <select
                  required
                  className="select"
                  value={scheduleForm.applicant_id}
                  onChange={e => setScheduleForm({ ...scheduleForm, applicant_id: e.target.value })}
                >
                  <option value="">-- Choose student --</option>
                  {applicants.map(a => (
                    <option key={a.id} value={a.id}>
                      {a.first_name} {a.last_name} ({a.application_no} • {a.grade_applying})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Assessment Type</label>
                <select
                  className="select"
                  value={scheduleForm.assessment_type}
                  onChange={e => setScheduleForm({ ...scheduleForm, assessment_type: e.target.value })}
                >
                  <option value="Entrance Exam">Entrance Exam (Math & English)</option>
                  <option value="Parent Interview">Parent & Family Interview</option>
                  <option value="Faculty Placement">Faculty Placement Assessment</option>
                  <option value="Diagnostic Assessment">Diagnostic & Special Needs Assessment</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold mb-1">Scheduled Date</label>
                  <input
                    type="date"
                    required
                    className="input"
                    value={scheduleForm.scheduled_at}
                    onChange={e => setScheduleForm({ ...scheduleForm, scheduled_at: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold mb-1">Max Score</label>
                  <input
                    type="number"
                    required
                    className="input"
                    value={scheduleForm.max_score}
                    onChange={e => setScheduleForm({ ...scheduleForm, max_score: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Interviewer / Faculty Panel</label>
                <input
                  type="text"
                  required
                  className="input"
                  value={scheduleForm.interviewer_name}
                  onChange={e => setScheduleForm({ ...scheduleForm, interviewer_name: e.target.value })}
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setShowScheduleModal(false)} className="btn btn-ghost text-xs">Cancel</button>
                <button type="submit" className="btn btn-primary text-xs">Schedule</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record Score Modal */}
      {scoreModalAssessment && (
        <div className="modal-backdrop" onClick={() => setScoreModalAssessment(null)}>
          <div className="modal !max-w-md" onClick={e => e.stopPropagation()}>
            <div className="eyebrow">Evaluation Results</div>
            <h3 className="text-lg font-serif font-bold text-foreground mb-1">
              Record Score: {scoreModalAssessment.applicant_name}
            </h3>
            <p className="text-xs text-muted-foreground mb-4">
              {scoreModalAssessment.assessment_type} ({scoreModalAssessment.grade})
            </p>

            <form onSubmit={handleScoreSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold mb-1">
                  Score Attained (out of {scoreModalAssessment.max_score}) *
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  max={scoreModalAssessment.max_score}
                  required
                  className="input font-mono font-bold text-base"
                  value={scoreForm.score}
                  onChange={e => setScoreForm({ ...scoreForm, score: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Admissions Recommendation *</label>
                <select
                  className="select"
                  value={scoreForm.recommendation}
                  onChange={e => setScoreForm({ ...scoreForm, recommendation: e.target.value })}
                >
                  <option value="Recommend Full Admission">Recommend Full Admission</option>
                  <option value="Conditional">Conditional on Academic Support</option>
                  <option value="Needs Learning Support Review">Needs Learning Support Review</option>
                  <option value="Placement on Waitlist">Placement on Waitlist</option>
                  <option value="Under Review by Academic Council">Under Review by Academic Council</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Faculty Evaluator Notes</label>
                <textarea
                  className="textarea !h-20"
                  placeholder="Strong analytical ability, recommended for accelerated mathematics..."
                  value={scoreForm.notes}
                  onChange={e => setScoreForm({ ...scoreForm, notes: e.target.value })}
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setScoreModalAssessment(null)} className="btn btn-ghost text-xs">Cancel</button>
                <button type="submit" className="btn btn-primary text-xs">Save & Complete Assessment</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
